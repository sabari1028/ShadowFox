from flask import Flask, render_template, request, send_file
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from fpdf import FPDF
import os
from io import BytesIO
import matplotlib
matplotlib.use('Agg')

app = Flask(__name__)

# Load and preprocess dataset
df = pd.read_csv("delhiaqi.csv")
df.columns = [col.strip().lower() for col in df.columns]
df['date'] = pd.to_datetime(df['date'], errors='coerce')
df['pm2_5'] = pd.to_numeric(df['pm2_5'], errors='coerce')

def calculate_aqi(pm25):
    if pm25 <= 30: return 50
    elif pm25 <= 60: return 100
    elif pm25 <= 90: return 150
    elif pm25 <= 120: return 200
    elif pm25 <= 250: return 300
    else: return 400

def aqi_category(aqi):
    if aqi <= 50: return 'Good'
    elif aqi <= 100: return 'Satisfactory'
    elif aqi <= 200: return 'Moderate'
    elif aqi <= 300: return 'Poor'
    elif aqi <= 400: return 'Very Poor'
    else: return 'Severe'

df['aqi'] = df['pm2_5'].apply(calculate_aqi)
df['category'] = df['aqi'].apply(aqi_category)
df.dropna(subset=['aqi', 'date'], inplace=True)
df['month'] = df['date'].dt.month

def create_filtered_charts(month=None, pollutant=None):
    if not os.path.exists("static"):
        os.makedirs("static")

    filtered_df = df.copy()
    if month:
        filtered_df = filtered_df[filtered_df['month'] == int(month)]

    if pollutant and pollutant in df.columns:
        plt.figure(figsize=(10, 5))
        sns.lineplot(data=filtered_df, x='date', y=pollutant)
        plt.title(f'{pollutant.upper()} Levels Over Time')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig('static/custom_pollutant.png')
        plt.close()
    else:
        plt.figure(figsize=(10, 5))
        sns.lineplot(data=filtered_df, x='date', y='aqi')
        plt.title('AQI Over Time')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig('static/aqi_trend.png')
        plt.close()

@app.route('/', methods=['GET', 'POST'])
def index():
    month = request.form.get('month')
    pollutant = request.form.get('pollutant')

    create_filtered_charts(month, pollutant)

    latest = df.sort_values(by='date', ascending=False).iloc[0]
    months = sorted(df['month'].unique())
    pollutants = ['pm2_5', 'pm10', 'no2', 'so2', 'co', 'o3']

    # Historical AQI average by month
    monthly_avg = df.groupby('month')['aqi'].mean().reset_index()

    return render_template(
        'index.html',
        latest=latest,
        category=aqi_category(latest['aqi']),
        months=months,
        pollutants=pollutants,
        selected_month=month,
        selected_pollutant=pollutant,
        monthly_avg=monthly_avg
    )
@app.route('/download')
def download_report():
    latest = df.sort_values(by='date', ascending=False).iloc[0]

    # Save chart temporarily
    chart_path = "static/aqi_trend_report.png"
    plt.figure(figsize=(10, 5))
    sns.lineplot(data=df, x='date', y='aqi')
    plt.title('AQI Over Time')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(chart_path)
    plt.close()

    # Create PDF
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=14)
    pdf.cell(200, 10, txt="Delhi AQI Report", ln=True, align='C')
    pdf.ln(10)
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt=f"Date: {latest['date'].date()}", ln=True)
    pdf.cell(200, 10, txt=f"AQI (PM2.5): {latest['aqi']} - Category: {aqi_category(latest['aqi'])}", ln=True)
    pdf.cell(200, 10, txt=f"PM2.5: {latest['pm2_5']}, PM10: {latest['pm10']}", ln=True)
    pdf.ln(10)

    # Embed image into PDF
    if os.path.exists(chart_path):
        pdf.image(chart_path, x=10, y=80, w=180)
    
    pdf_output = BytesIO()
    pdf_bytes = pdf.output(dest='S').encode('latin1')
    pdf_output.write(pdf_bytes)
    pdf_output.seek(0)

    return send_file(pdf_output, download_name="Delhi_AQI_Report.pdf", as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
